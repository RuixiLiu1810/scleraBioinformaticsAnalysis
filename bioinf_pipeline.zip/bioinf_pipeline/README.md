# bioinf_pipeline (R)

A modular bioinformatics pipeline skeleton supporting:
- Raw counts -> DESeq2
- TPM/FPKM (normalized) -> limma (log2(x+1) by default)
- Species switch: hs / mm
- External key: SYMBOL (internal enrichment uses ENTREZID)

## Quick start

1) Prepare `meta.csv` with at least: `sample_id,group` (optional: batch, covariates).
2) Prepare expression tables:
   - Raw counts: first column `SYMBOL`, remaining columns are sample IDs
   - TPM/FPKM: first column `SYMBOL`, remaining columns are sample IDs

### Run (raw counts)
```r
source("R/config.R")
source("R/io_table.R")
source("R/preprocess.R")
source("R/design.R")
source("R/de_deseq2.R")
source("R/idmap.R")
source("R/enrich.R")
source("R/viz.R")
source("R/export.R")
source("R/pipeline.R")

cfg <- make_cfg(
  species="hs",
  input_type="counts_table",
  outdir="outputs_counts",
  contrasts=list(c("group","HL","L"))
)
cfg$expr <- list(scale="raw", log_transform=FALSE)

run_pipeline(cfg, input=list(file="raw_counts.tsv", meta="meta.csv", gene_col="SYMBOL"), engine="deseq2")
```

### Run (TPM/FPKM)
```r
cfg <- make_cfg(
  species="hs",
  input_type="expr_table",
  outdir="outputs_tpm",
  contrasts=list(c("group","HL","L"))
)
cfg$expr <- list(scale="tpm", log_transform=TRUE) # log2(x+1)

run_pipeline(cfg, input=list(file="tpm_matrix.tsv", meta="meta.csv", gene_col="SYMBOL"), engine="limma")
```

## Notes
- Enrichment (GO/KEGG) is attempted for UP genes; failures are non-fatal.
- Heatmap is provided as a helper; for raw counts it uses DESeq2 VST output saved as RDS.
