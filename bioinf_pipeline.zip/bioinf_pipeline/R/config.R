get_species_map <- function(species = c("hs","mm")) {
  species <- match.arg(species)
  if (species == "hs") {
    list(
      species = "hs",
      orgdb_pkg = "org.Hs.eg.db",
      kegg = "hsa"
    )
  } else {
    list(
      species = "mm",
      orgdb_pkg = "org.Mm.eg.db",
      kegg = "mmu"
    )
  }
}

make_cfg <- function(
  species = c("hs","mm"),
  input_type = c("geo","counts_table","expr_table","seurat"),
  outdir = "outputs",
  group_col = "group",
  design = "~ group",
  contrasts = list(c("group","A","B")),
  cutoff = list(padj = 0.05, logFC = 1)
){
  sp <- get_species_map(match.arg(species))
  cfg <- list(
    species = sp$species,
    orgdb_pkg = sp$orgdb_pkg,
    kegg_org = sp$kegg,
    input = list(type = match.arg(input_type)),
    design = list(group_col = group_col, formula = design, contrasts = contrasts),
    cutoff = cutoff,
    outdir = outdir
  )
  cfg
}
