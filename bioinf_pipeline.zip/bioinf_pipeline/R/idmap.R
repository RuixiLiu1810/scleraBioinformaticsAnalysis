ensure_orgdb <- function(cfg) {
  if (!requireNamespace(cfg$orgdb_pkg, quietly = TRUE)) {
    stop(sprintf("Missing OrgDb package: %s", cfg$orgdb_pkg))
  }
  get(cfg$orgdb_pkg)
}

symbol_to_entrez <- function(symbols, cfg, allow_alias = TRUE) {
  if (!requireNamespace("AnnotationDbi", quietly = TRUE)) stop("Please install AnnotationDbi")
  OrgDb <- ensure_orgdb(cfg)

  symbols <- unique(as.character(symbols))
  symbols <- symbols[!is.na(symbols) & nzchar(symbols)]

  m1 <- AnnotationDbi::select(
    OrgDb,
    keys = symbols,
    keytype = "SYMBOL",
    columns = c("SYMBOL", "ENTREZID")
  )
  m1 <- m1[!is.na(m1$ENTREZID), c("SYMBOL","ENTREZID"), drop=FALSE]

  if (!allow_alias) return(unique(m1))

  mapped_sym <- unique(m1$SYMBOL)
  rest <- setdiff(symbols, mapped_sym)
  if (length(rest) == 0) return(unique(m1))

  m2 <- AnnotationDbi::select(
    OrgDb,
    keys = rest,
    keytype = "ALIAS",
    columns = c("ALIAS", "ENTREZID")
  )
  colnames(m2)[colnames(m2)=="ALIAS"] <- "SYMBOL"
  m2 <- m2[!is.na(m2$ENTREZID), c("SYMBOL","ENTREZID"), drop=FALSE]

  unique(rbind(m1, m2))
}
